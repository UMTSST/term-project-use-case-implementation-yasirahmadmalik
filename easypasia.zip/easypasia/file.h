#include <iostream>
#include <string.h>
    #include <stdio.h>
     #include <stdlib.h>
       #include <conio.h>
        #include <fstream>


  using namespace std;


  class file
  {


  private:
    bool flag3;




    string srec,ssen,bal;
  public:


    bool setflag3(bool);
    bool getflag3();

      bool searchinfo(string);




  };
